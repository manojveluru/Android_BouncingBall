package manojveluru.niu.edu.bouncingball;
/********************************************************************
 CSCI 522 - Portfolio 10 - Semester (Spring) Year - 2019

 Programmer(s): Manoj Veluru
 Section: 1
 TA: Harshith Desamsetti
 Date Due: 04/03/2019

 Purpose: BouncingBall

 *********************************************************************/
import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.FrameLayout;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create a frame layout and connect it to the screen
        FrameLayout layout = findViewById(R.id.frameLayout);

        //create bounce surface view
        BounceSurfaceView bounceSurfaceView = new BounceSurfaceView(this, null);

        //add the surface view to thje frame Layout
        layout.addView(bounceSurfaceView);
    }//end onCreate
}
