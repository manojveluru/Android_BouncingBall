package manojveluru.niu.edu.bouncingball;

import android.graphics.Canvas;

public class AnimationArena
{
    private Ball myBall;

    public AnimationArena()
    {
        //create the Ball object
        myBall = new Ball();
    }//end constructor

    //method to update the location of the ball
    public void update(int width, int height)
    {
        myBall.move(0,0,width,height);
    }//end update

    //method to draw
    public void draw(Canvas canvas)
    {
        //set the background color for the canvas
        canvas.drawRGB(156,174,216);

        //draw the ball on the canvas
        myBall.draw(canvas);
    }//end draw
}//end AnimationArena
