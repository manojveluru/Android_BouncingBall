package manojveluru.niu.edu.bouncingball;

import android.content.Context;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class BounceSurfaceView extends SurfaceView implements SurfaceHolder.Callback
{
   private BounceThread bounceThread;

   public BounceSurfaceView(Context context, AttributeSet attributeSet)
   {
       super(context, attributeSet);

       //create a Surface holder
       SurfaceHolder holder = getHolder();

       //attach the callback methods to the surface holder
       holder.addCallback(this);

       //attach the surface holder to the bouncing thresd
       bounceThread = new BounceThread(holder);
   }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        //start thread execution
        bounceThread.start();
    }//end surfaceCreated

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }//end surfaceChanged

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
       //stop execution of the thread by ending the animation
        bounceThread.endBounce();

        //nullify the thread
        Thread dummyThread = bounceThread;
        bounceThread = null;
        dummyThread.interrupt();


    }//end surfaceDestroyed
}
