package manojveluru.niu.edu.bouncingball;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class BounceThread extends Thread
{
    private SurfaceHolder surfaceHolder;

    private AnimationArena animationArena;

    private boolean isRunning;

    public BounceThread(SurfaceHolder sh)
    {
        surfaceHolder = sh;

        //inmitialize boolean variable to indicate application is running
        isRunning = true;

        //create the animation arena
        animationArena = new AnimationArena();
    }//end constructor

    public void run()
    {
        try
        {
            while (isRunning)
            {
                //create a canvas and lock it so that nothing else can make a change to it
                Canvas canvas = surfaceHolder.lockCanvas();

                //update the ball location
                animationArena.update(canvas.getWidth(),canvas.getHeight());
                animationArena.draw(canvas);

                //unlock the canvas so that it can be updated
                surfaceHolder.unlockCanvasAndPost(canvas);
            }
        }
        catch (NullPointerException npe)
        {
            npe.printStackTrace();
        }
    }//end run method

    public void endBounce()
    {
        isRunning = false;
    }
}//end BounceThread
